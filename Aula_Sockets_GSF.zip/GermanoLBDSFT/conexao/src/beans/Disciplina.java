/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

/**
 *
 * @author laboratorio
 */
public class Disciplina {
    
    private int id;
    private String nome;
    private int carga_horaria;
    private Professor professor_id;

    public Disciplina(int id, String nome, int carga_horaria, Professor professor_id) {
        this.id = id;
        this.nome = nome;
        this.carga_horaria = carga_horaria;
        this.professor_id = professor_id;
    }

    
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getCarga_horaria() {
        return carga_horaria;
    }

    public void setCarga_horaria(int carga_horaria) {
        this.carga_horaria = carga_horaria;
    }

    public Professor getProfessor_id() {
        return professor_id;
    }

    public void setProfessor_id(Professor professor_id) {
        this.professor_id = professor_id;
    }
    
}
