/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import beans.Professor;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author laboratorio
 */
public class ProfessorDAO {
    
    private Conexao conexao;
    private Connection conn;
    
    public ProfessorDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
       
    }
    
    public List<Professor> getProfessoresNome(String nome){
        
        String sql = "SELECT * FROM PROFESSORES WHERE nome LIKE ?";
        try{
            
            PreparedStatement stmt = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            
            stmt.setString(1,"%"+nome+"%");
            
            ResultSet rs = stmt.executeQuery();
            List<Professor> listaProfessores = new ArrayList<>();
            
            while (rs.next()){
                
                listaProfessores.add(new Professor(
                                            rs.getInt("id"),
                                            rs.getString("nome"),
                                            rs.getString("email")
                                            )
                                );
                
            }
            return listaProfessores;
        
        } catch(SQLException ex){
            
            System.out.println("Erro "+ex.getMessage());
            return null;
            
        }
        
    }
    
    public List<Professor> getProfessores(){
        
        String sql = "SELECT * FROM PROFESSORES";
        
        try{
            
            PreparedStatement stmt = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            
            ResultSet rs = stmt.executeQuery();
            List<Professor> listaProfessores = new ArrayList<>();
            
            while (rs.next()){
                
                listaProfessores.add(new Professor(
                                            rs.getInt("id"),
                                            rs.getString("nome"),
                                            rs.getString("email")
                                            )
                                );
                
            }
            return listaProfessores;
            
        } catch (SQLException ex){
            
            System.out.println("Erro: "+ex.getMessage());
            return null;
            
        }
        
    }
    
    public Professor getProfessor(int id){
        
        String sql = "SELECT * FROM PROFESSORES WHERE id = ?";
        try{
            
            PreparedStatement stmt = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            
            stmt.setInt(1,id);
            
            ResultSet rs = stmt.executeQuery();
            
            return new Professor(rs.getInt("id"),
                                 rs.getString("nome"),
                                 rs.getString("email")
                                );
            
        }catch(SQLException ex){
            
            System.out.println("Erro "+ex.getMessage());
            return null;
            
        }   
        
    }
    
    public void editar(Professor professor){
        
        try{
            
            String sql = "UPDATE PROFESSOR SET nome = ?, email = ? WHERE id = ?";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1,professor.getNome());
            stmt.setString(2,professor.getEmail());
            stmt.setInt(3,professor.getId());
            stmt.execute();
            
        }
        catch(SQLException ex){
            
            System.out.println("Erro ao atualizar professor: " + ex.getMessage());
            
        }
        
    }
    
    public void excluir(int id){
        
        try{
            
            String sql = "DELETE FROM PROFESSORES WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
            
        }
        catch(SQLException ex){
            
            System.out.println("Erro ao excluir professor: " + ex.getMessage());
            
        }
        
    }
    
      public void inserir(Professor professor){
          String sql = "INSERT INTO PROFESSORES (nome,email) VALUES (?,?)";
          
          try{
              PreparedStatement stmt = this.conn.prepareStatement(sql);
              stmt.setString(1,professor.getNome());
              stmt.setString(2,professor.getEmail());
              
              
              stmt.execute();
              
          }
          catch(SQLException ex){
              System.out.println("Erro ao inserir professor: "+ex.getMessage());
              
          }
      }
}
