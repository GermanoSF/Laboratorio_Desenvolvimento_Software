/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import beans.Disciplina;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author laboratorio
 */
public class DisciplinaDAO {
    
    private Conexao conexao;
    private Connection conn;
    
    public DisciplinaDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
       
    }
    
    public List<Disciplina> getDisciplinasNome(String nome){
        
        String sql = "SELECT * FROM DISCIPLINAS WHERE nome LIKE ?";
        
        try{
            
            PreparedStatement stmt = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            
            stmt.setString(1,"%"+nome+"%");
            
            ResultSet rs = stmt.executeQuery();
            List<Disciplina> listaDisciplinas = new ArrayList<>();
            
            ProfessorDAO pDAO = new ProfessorDAO();
            
            while (rs.next()){
                
                listaDisciplinas.add(new Disciplina(
                                            rs.getInt("id"),
                                            rs.getString("nome"),
                                            rs.getInt("carga_horaria"),
                                            pDAO.getProfessor(rs.getInt("professor_id"))
                                            )
                                    );
                
            }
            return listaDisciplinas;
            
        } catch (SQLException ex){
            
            System.out.println("Erro: "+ex.getMessage());
            return null;
            
        }
        
    }
    
    public List<Disciplina> getDisciplinas(){
        
        String sql = "SELECT * FROM DISCIPLINAS";
        
        try{
            
            PreparedStatement stmt = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            
            ResultSet rs = stmt.executeQuery();
            
            List<Disciplina> listaDisciplinas = new ArrayList<>();
            
            ProfessorDAO pDAO = new ProfessorDAO();
            
            while (rs.next()){
                
                listaDisciplinas.add(new Disciplina(
                                            rs.getInt("id"),
                                            rs.getString("nome"),
                                            rs.getInt("carga_horaria"),
                                            pDAO.getProfessor(rs.getInt("professor_id"))
                                            )
                                    );
                
            }
            return listaDisciplinas;
            
        } catch (SQLException ex){
            
            System.out.println("Erro: "+ex.getMessage());
            return null;
            
        }
        
    }
    
    public void editar(Disciplina disciplina){
        
        try{
            
            String sql = "UPDATE DISCIPLINAS SET nome = ?, carga_horaria = ?, professor_id = ? WHERE id = ?";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1,disciplina.getNome());
            stmt.setInt(2,disciplina.getCarga_horaria());
            stmt.setInt(3,disciplina.getProfessor_id().getId());
            stmt.setInt(4,disciplina.getId());
            stmt.execute();
            
        }
        catch(SQLException ex){
            
            System.out.println("Erro ao atualizar disciplina: " + ex.getMessage());
            
        }
        
    }
    
    public void excluir(int id){
        
        try{
            
            String sql = "DELETE FROM DISCIPLINAS WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
            
        }
        catch(SQLException ex){
            
            System.out.println("Erro ao excluir disciplina: " + ex.getMessage());
            
        }
        
    }
    
      public void inserir(Disciplina disciplina){
          String sql = "INSERT INTO DISCIPLINAS (nome,carga_horaria,professor_id) VALUES (?,?,?)";
          
          try{
              PreparedStatement stmt = this.conn.prepareStatement(sql);
              stmt.setString(1,disciplina.getNome());
              stmt.setInt(2,disciplina.getCarga_horaria());
              stmt.setInt(3,disciplina.getProfessor_id().getId());
              
              
              stmt.execute();
              
          }
          catch(SQLException ex){
              System.out.println("Erro ao inserir disciplina: "+ex.getMessage());
              
          }
      }
}
