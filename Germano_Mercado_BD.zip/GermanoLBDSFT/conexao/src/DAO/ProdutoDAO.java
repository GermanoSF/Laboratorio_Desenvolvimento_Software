/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import beans.Produto;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author laboratorio
 */
public class ProdutoDAO {
    
    private Conexao conexao;
    private Connection conn;
    
    public ProdutoDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
       
    }
    
    public List<Produto> getProdutos(){
        
        String sql = "SELECT * FROM PRODUTOS";
        
        try{
            
            PreparedStatement stmt = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            
            ResultSet rs = stmt.executeQuery();
            List<Produto> listaProdutos = new ArrayList<>();
            
            while (rs.next()){
                
                CategoriaDAO cDAO = new CategoriaDAO();
                
                listaProdutos.add(new Produto(
                                            rs.getInt("id"),
                                            rs.getString("nome"),
                                            rs.getFloat("preco"),
                                            rs.getInt("quantidade"),
                                            cDAO.getCategoria(rs.getInt("categoria_id"))
                                            )
                                );
            }
            return listaProdutos;
            
        } catch (SQLException ex){
            
            System.out.println("Erro: "+ex.getMessage());
            return null;
            
        }
        
    }
    
    public Produto getProduto(int id){
        
        String sql = "SELECT * FROM PRODUTOS WHERE id = ?";
        
        try{
            
            PreparedStatement stmt = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            
            stmt.setInt(1,id);
            ResultSet rs = stmt.executeQuery();
            Produto p = new Produto();
            rs.first();
            p.setId(id);
            p.setNome(rs.getString("nome"));
            p.setPreco(rs.getFloat("preco"));
            p.setQuantidade(rs.getInt("quantidade"));
            
            CategoriaDAO cDAO = new CategoriaDAO();
            
            p.setCategoria_id(cDAO.getCategoria(rs.getInt("categoria_id")));
            
            return p;
            
        }
        catch(SQLException ex){
            
            System.out.println("Falha ao consultar produto: " + ex.getMessage());
            return null;
            
        }
        
    }
    
    public void editar(Produto produto){
        
        try{
            
            String sql = "UPDATE PRODUTOS set nome = ?, preco = ?, quantidade = ?, categoria_id = ? WHERE id = ?";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1,produto.getNome());
            stmt.setFloat(2,produto.getPreco());
            stmt.setInt(3,produto.getQuantidade());
            stmt.setInt(4,produto.getCategoria_id().getId());
            stmt.execute();
            
        }
        catch(SQLException ex){
            
            System.out.println("Erro ao atualizar produto: " + ex.getMessage());
            
        }
        
    }
    
    public void excluir(int id){
        
        try{
            
            String sql = "DELETE FROM PRODUTOS WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
            
        }
        catch(SQLException ex){
            
            System.out.println("Erro ao excluir produto: " + ex.getMessage());
            
        }
        
    }
    
      public void inserir(Produto produto){
          String sql = "INSERT INTO PRODUTOS (nome,preco,quantidade,categoria_id) VALUES (?,?,?,?)";
          
          try{
              PreparedStatement stmt = this.conn.prepareStatement(sql);
              stmt.setString(1,produto.getNome());
              stmt.setFloat(2,produto.getPreco());
              stmt.setInt(2,produto.getQuantidade());
              stmt.setInt(3,produto.getCategoria_id().getId());
              
              
              stmt.execute();
              
          }
          catch(SQLException ex){
              System.out.println("Erro ao inserir produto: "+ex.getMessage());
              
          }
      }
}
