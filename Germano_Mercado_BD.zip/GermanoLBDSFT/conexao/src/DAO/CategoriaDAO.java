/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import beans.Categoria;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author laboratorio
 */
public class CategoriaDAO {
    
    private Conexao conexao;
    private Connection conn;
    
    public CategoriaDAO(){
        this.conexao = new Conexao();
        this.conn = this.conexao.getConexao();
       
    }
    
    public List<Categoria> getCategorias(){
        
        String sql = "SELECT * FROM CATEGORIAS";
        
        try{
            
            PreparedStatement stmt = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            
            ResultSet rs = stmt.executeQuery();
            List<Categoria> listaCategorias = new ArrayList<>();
            
            while (rs.next()){
                
                listaCategorias.add(new Categoria(
                                            rs.getInt("id"),
                                            rs.getString("nome")
                                            )
                                );
                
            }
            return listaCategorias;
            
        } catch (SQLException ex){
            
            System.out.println("Erro: "+ex.getMessage());
            return null;
            
        }
        
    }
    
    public Categoria getCategoria(int id){
        
        String sql = "SELECT * FROM CATEGORIAS WHERE id = ?";
        
        try{
            
            PreparedStatement stmt = conn.prepareStatement(sql,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
            
            stmt.setInt(1,id);
            ResultSet rs = stmt.executeQuery();
            Categoria c = new Categoria();
            rs.first();
            c.setId(id);
            c.setNome(rs.getString("nome"));
            
            return c;
            
        }
        catch(SQLException ex){
            
            System.out.println("Falha ao consultar categoria: " + ex.getMessage());
            return null;
            
        }
        
    }
    
    public void editar(Categoria categoria){
        
        try{
            
            String sql = "UPDATE CATEGORIAS set nome = ? WHERE id = ?";
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1,categoria.getNome());
            stmt.setInt(4,categoria.getId());
            stmt.execute();
            
        }
        catch(SQLException ex){
            
            System.out.println("Erro ao atualizar categoria: " + ex.getMessage());
            
        }
        
    }
    
    public void excluir(int id){
        
        try{
            
            String sql = "DELETE FROM CATEGORIAS WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
            
        }
        catch(SQLException ex){
            
            System.out.println("Erro ao excluir categoria: " + ex.getMessage());
            
        }
        
    }
    
      public void inserir(Categoria categoria){
          String sql = "INSERT INTO CATEGORIAS (nome) VALUES (?)";
          
          try{
              PreparedStatement stmt = this.conn.prepareStatement(sql);
              stmt.setString(1,categoria.getNome());
              
              
              stmt.execute();
              
          }
          catch(SQLException ex){
              System.out.println("Erro ao inserir categoria: "+ex.getMessage());
              
          }
      }
}
